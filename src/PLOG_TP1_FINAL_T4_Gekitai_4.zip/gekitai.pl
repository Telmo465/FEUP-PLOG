:-consult('play.pl').
:-consult('display.pl').
:-consult('input.pl').
:-consult('utils.pl').
:-consult('menu.pl').
:-dynamic(state/2).
:-use_module(library(lists)).
:-use_module(library(random)).

gekitai :-
	play. 


